package com.example.moneyexpensestracker;

public interface NavSetup {
    void EventBottomNav();
}
